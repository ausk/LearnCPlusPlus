info2="This is a file in the sample/test2.py"
def show2():
    print(__file__)
    print(info)
