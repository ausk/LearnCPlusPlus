from __future__ import absolute_import
from __future__ import print_function

from . import test2
from .test3 import *

import sys,os

def main(args=None):
    """The main routine."""
    if args is None:
        args = sys.argv[1:]

    print("This is the main routine.")
    print("It should do something interesting.")

    # Do argument parsing here (eg. with argparse) and anything else
    # you want your project to do.

if __name__ == "__main__":
    here =  __file__[__file__.rfind(os.path.sep):]
    print("starting path:",here)
    main()
