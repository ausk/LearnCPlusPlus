info3="This is a file in the sample/test3.py"
def show3():
    print(__file__)
    print(info)
