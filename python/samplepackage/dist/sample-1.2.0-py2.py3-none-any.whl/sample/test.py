info="This is a file in the sample/test.py"
def show():
    print(__file__)
    print(info)
